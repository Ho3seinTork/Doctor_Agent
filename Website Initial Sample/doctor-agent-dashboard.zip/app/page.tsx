"use client"

import { useState } from "react"
import { LeftSidebar } from "@/components/left-sidebar"
import { CentralContent } from "@/components/central-content"
import { RightPanel } from "@/components/right-panel"
import { MobileNav } from "@/components/mobile-nav"
import { SidebarInset } from "@/components/ui/sidebar"
import { useIsMobile } from "@/hooks/use-mobile"
import { UnifiedHeader } from "@/components/unified-header"

export default function Dashboard() {
  const isMobile = useIsMobile()
  const [rightPanelOpen, setRightPanelOpen] = useState(false)

  const toggleRightPanel = () => {
    setRightPanelOpen(!rightPanelOpen)
  }

  return (
    <div className="flex h-screen flex-col">
      <UnifiedHeader rightPanelOpen={rightPanelOpen} onRightPanelToggle={toggleRightPanel} />

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Hidden on mobile, collapsible on desktop */}
        <div className="hidden md:block">
          <LeftSidebar />
        </div>

        {/* Central Content - Expands to fill available space */}
        <SidebarInset className="flex-1">
          <div className="flex h-full flex-col">
            <div className="flex-1 overflow-auto">
              <CentralContent />
            </div>
          </div>
        </SidebarInset>

        {/* Right Panel - Hidden on mobile, toggleable on desktop */}
        <div className={`hidden transition-all duration-300 ${rightPanelOpen ? "md:block md:w-72 lg:w-80" : "md:w-0"}`}>
          {rightPanelOpen && <RightPanel />}
        </div>
      </div>

      {/* Mobile Navigation */}
      <MobileNav />
    </div>
  )
}

