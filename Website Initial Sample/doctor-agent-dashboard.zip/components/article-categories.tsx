"use client"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

interface ArticleCategoryProps {
  onCategoryChange: (category: string) => void
  activeCategory: string
}

export function ArticleCategories({ onCategoryChange, activeCategory }: ArticleCategoryProps) {
  const categories = [
    { id: "all", label: "All Articles" },
    { id: "mental-health", label: "Mental Health" },
    { id: "healthy-living", label: "Healthy Living" },
    { id: "nutrition", label: "Nutrition & Diet" },
    { id: "sexual-health", label: "Sexual Health" },
    { id: "mother-child", label: "Mother & Child" },
    { id: "beauty", label: "Beauty" },
    { id: "skin-hair", label: "Skin & Hair" },
    { id: "diseases", label: "Diseases" },
    { id: "medications", label: "Medications" },
    { id: "news", label: "News" },
  ]

  return (
    <ScrollArea className="w-full whitespace-nowrap">
      <div className="flex space-x-2 py-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
              activeCategory === category.id
                ? "bg-medical-primary text-white"
                : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
            }`}
          >
            {category.label}
          </button>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  )
}

