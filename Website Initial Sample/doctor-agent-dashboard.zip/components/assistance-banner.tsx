"use client"

import { Info, ArrowRight, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export function AssistanceBanner() {
  const [open, setOpen] = useState(false)
  const [includeAI, setIncludeAI] = useState(true)

  return (
    <div className="bg-blue-50 rounded-lg p-4 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between">
      <div className="flex items-center mb-4 sm:mb-0">
        <div className="bg-blue-100 rounded-full p-3 mr-4">
          <Info className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-blue-900">Need immediate assistance?</h2>
          <p className="text-blue-700">Our AI can quickly assess your symptoms</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              Start AI Triage <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Create Consultation</DialogTitle>
              <DialogDescription>
                Start a consultation with a doctor and AI assistance for immediate help.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="specialty">Medical Specialty</Label>
                <Select defaultValue="general">
                  <SelectTrigger id="specialty">
                    <SelectValue placeholder="Select specialty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Practitioner</SelectItem>
                    <SelectItem value="cardiology">Cardiology</SelectItem>
                    <SelectItem value="dermatology">Dermatology</SelectItem>
                    <SelectItem value="neurology">Neurology</SelectItem>
                    <SelectItem value="pediatrics">Pediatrics</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="urgency">Urgency Level</Label>
                <Select defaultValue="moderate">
                  <SelectTrigger id="urgency">
                    <SelectValue placeholder="Select urgency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low - General Question</SelectItem>
                    <SelectItem value="moderate">Moderate - Need Advice</SelectItem>
                    <SelectItem value="high">High - Urgent Concern</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-ai"
                  checked={includeAI}
                  onCheckedChange={(checked) => setIncludeAI(checked as boolean)}
                />
                <Label htmlFor="include-ai" className="text-sm">
                  Include AI Assistant in conversation
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => setOpen(false)} className="bg-blue-600 hover:bg-blue-700 text-white">
                <Users className="mr-2 h-4 w-4" />
                Start Multi-Person Chat
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Button variant="outline" className="border-blue-200 text-blue-700 hover:bg-blue-100">
          Check Symptoms
        </Button>
      </div>
    </div>
  )
}

