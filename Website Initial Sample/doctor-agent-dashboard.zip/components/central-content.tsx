"use client"
import { useState } from "react"
import { Stethoscope, Newspaper, PhoneCall } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { HealthMonitoring } from "./health-monitoring"
import { DoctorArticles } from "./doctor-articles"
import { CoAiArticleWriter } from "./co-ai-article-writer"
import { HeroBanner } from "./hero-banner"
import { FeatureCards } from "./feature-cards"
import { Tagline } from "./tagline"
import { TopDoctors } from "./top-doctors"
import { MedicalFacilities } from "./medical-facilities"

export function CentralContent() {
  const [coAiDialogOpen, setCoAiDialogOpen] = useState(false)

  const handleCoAiClick = () => {
    setCoAiDialogOpen(true)
  }

  return (
    <div className="flex-1 overflow-y-auto p-4">
      {/* Hero Banner */}
      <HeroBanner />

      {/* Tagline */}
      <Tagline />

      {/* Feature Cards - Full width container */}
      <div className="w-full mb-10 px-0">
        <FeatureCards onCoAiClick={handleCoAiClick} />
      </div>

      {/* Health Monitoring Widget */}
      <div className="mt-8">
        <HealthMonitoring />
      </div>

      {/* Doctor Articles Section */}
      <div className="mt-2">
        <Card className="border border-blue-200 bg-blue-50 mb-4">
          <CardContent className="p-4">
            <div className="flex items-start">
              <div className="bg-blue-100 rounded-full p-2 mr-3">
                <Newspaper className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-medium text-blue-900">Personalized Health Insights</h3>
                <p className="text-sm text-blue-700">
                  Based on your sleep patterns and heart rate data, we've curated these articles to help you improve
                  your health.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <DoctorArticles />
      </div>

      {/* Top Doctors Section */}
      <div className="mt-8">
        <TopDoctors />
      </div>

      {/* Medical Facilities Section */}
      <div className="mt-8">
        <MedicalFacilities />
      </div>

      {/* Bottom Navigation */}
      <div className="border-t mt-6 pt-4">
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            className="flex-1 border-medical-primary text-medical-primary hover:bg-medical-accent"
          >
            <PhoneCall className="mr-2 h-4 w-4" />
            Request Consultation
          </Button>
          <div className="mx-2"></div>
          <Button className="flex-1 bg-medical-primary text-white hover:bg-medical-secondary">
            <Stethoscope className="mr-2 h-4 w-4" />
            Symptom Checker
          </Button>
        </div>
      </div>

      {/* Co-Ai Article Writer Dialog */}
      <CoAiArticleWriter open={coAiDialogOpen} onOpenChange={setCoAiDialogOpen} />
    </div>
  )
}

