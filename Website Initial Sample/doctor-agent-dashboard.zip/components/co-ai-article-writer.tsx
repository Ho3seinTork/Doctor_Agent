"use client"

import { useState } from "react"
import { FileText, Eye, Share2, Save, Download, Users } from "lucide-react"
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

interface CoAiArticleWriterProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CoAiArticleWriter({ open, onOpenChange }: CoAiArticleWriterProps) {
  const [activeTab, setActiveTab] = useState("editor")
  const [articleContent, setArticleContent] = useState(
    `# The Impact of Regular Exercise on Cardiovascular Health

Regular physical activity is one of the most important things you can do for your health. It can help:
- Control weight
- Reduce risk of cardiovascular disease
- Strengthen bones and muscles
- Improve mental health and mood

## How Exercise Affects Your Heart
When you exercise regularly, your heart becomes more efficient at pumping blood. This leads to lower blood pressure and heart rate, reducing strain on your cardiovascular system.`,
  )

  const aiSuggestions = [
    "Add a section about recommended exercise types for heart health.",
    "Include statistics on how exercise reduces heart disease risk.",
    "Add a paragraph about the relationship between exercise and cholesterol levels.",
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] p-0 max-h-[90vh] flex flex-col overflow-hidden">
        <div className="p-6 border-b flex-shrink-0">
          <DialogTitle className="text-xl font-bold">Co-Ai Article Writer</DialogTitle>
          <DialogDescription>Collaborate with AI to write medical articles</DialogDescription>
        </div>

        <Tabs
          defaultValue="editor"
          value={activeTab}
          onValueChange={setActiveTab}
          className="flex-1 flex flex-col overflow-hidden"
        >
          <TabsList className="grid grid-cols-3 border-b rounded-none flex-shrink-0">
            <TabsTrigger
              value="editor"
              className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none"
            >
              <FileText className="h-4 w-4" />
              Editor
            </TabsTrigger>
            <TabsTrigger
              value="preview"
              className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none"
            >
              <Eye className="h-4 w-4" />
              Preview
            </TabsTrigger>
            <TabsTrigger
              value="share"
              className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none"
            >
              <Share2 className="h-4 w-4" />
              Share
            </TabsTrigger>
          </TabsList>

          <TabsContent
            value="editor"
            className="flex-1 flex flex-col p-0 m-0 data-[state=inactive]:hidden overflow-hidden"
          >
            <div className="flex items-center p-4 border-b flex-shrink-0">
              <div className="flex items-center">
                <div className="h-4 w-4 rounded-full bg-green-500 mr-2"></div>
                <span className="text-sm text-muted-foreground">AI is ready to assist</span>
              </div>
              <div className="ml-auto">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Save className="h-4 w-4" />
                  Save Draft
                </Button>
              </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              <div className="flex-1 p-4 overflow-auto">
                <Textarea
                  value={articleContent}
                  onChange={(e) => setArticleContent(e.target.value)}
                  className="w-full h-full min-h-[300px] resize-none border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                />
              </div>

              <div className="w-full md:w-[240px] bg-gray-50 p-4 border-t md:border-t-0 md:border-l overflow-y-auto">
                <h3 className="font-medium mb-3">AI Suggestions</h3>
                <div className="space-y-2">
                  {aiSuggestions.map((suggestion, index) => (
                    <div
                      key={index}
                      className="p-3 bg-white border rounded-md text-sm cursor-pointer hover:bg-blue-50"
                      onClick={() => setArticleContent(articleContent + "\n\n" + suggestion)}
                    >
                      {suggestion}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="flex-1 p-0 m-0 data-[state=inactive]:hidden overflow-auto">
            <div className="p-6">
              <div className="prose max-w-none">
                <h1>The Impact of Regular Exercise on Cardiovascular Health</h1>
                <p>
                  Regular physical activity is one of the most important things you can do for your health. It can help:
                </p>
                <ul>
                  <li>Control weight</li>
                  <li>Reduce risk of cardiovascular disease</li>
                  <li>Strengthen bones and muscles</li>
                  <li>Improve mental health and mood</li>
                </ul>

                <h2>How Exercise Affects Your Heart</h2>
                <p>
                  When you exercise regularly, your heart becomes more efficient at pumping blood. This leads to lower
                  blood pressure and heart rate, reducing strain on your cardiovascular system.
                </p>

                <h2>Recommended Exercise Types for Heart Health</h2>
                <p>
                  The American Heart Association recommends at least 150 minutes per week of moderate-intensity aerobic
                  activity or 75 minutes per week of vigorous aerobic activity, or a combination of both, preferably
                  spread throughout the week.
                </p>

                <h2>Exercise and Heart Disease Risk</h2>
                <p>
                  Regular physical activity can reduce your risk of developing heart disease by 30-40%. It can also help
                  reduce the risk of stroke and certain types of cancer.
                </p>

                <h2>Exercise and Cholesterol</h2>
                <p>
                  Regular exercise has been shown to increase high-density lipoprotein (HDL, or "good") cholesterol and
                  decrease low-density lipoprotein (LDL, or "bad") cholesterol levels, which can reduce the buildup of
                  plaques in your arteries.
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="share" className="flex-1 p-0 m-0 data-[state=inactive]:hidden overflow-auto">
            <div className="p-6">
              <div className="space-y-6">
                <div className="bg-white border rounded-lg p-6">
                  <h2 className="text-lg font-semibold mb-2">Share with Healthcare Professionals</h2>
                  <p className="text-muted-foreground mb-4">
                    Share your article with doctors and specialists for review and feedback.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Button className="bg-gray-900 text-white hover:bg-gray-800">
                      <Share2 className="mr-2 h-4 w-4" />
                      Share Article
                    </Button>
                    <Button variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Export PDF
                    </Button>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold mb-4">Publishing Options</h2>
                  <div className="space-y-3">
                    <div className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                        <FileText className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Dr.Agent Health Blog</h3>
                        <p className="text-sm text-muted-foreground">Share with the community</p>
                      </div>
                    </div>

                    <div className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                        <Users className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Heart Health Group</h3>
                        <p className="text-sm text-muted-foreground">Share with your support group</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

