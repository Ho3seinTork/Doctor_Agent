"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, ArrowLeft, Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/button"
import { ArticleCategories } from "./article-categories"

interface Article {
  id: number
  title: string
  excerpt: string
  image: string
  author: {
    name: string
    avatar: string
    specialty: string
  }
  date: string
  readTime: string
  aiCoAuthored: boolean
  category: string
}

export function DoctorArticles() {
  const [currentPage, setCurrentPage] = useState(0)
  const [activeCategory, setActiveCategory] = useState("all")

  const articles: Article[] = [
    {
      id: 1,
      title: "Understanding Sleep Patterns: What Your Data Reveals",
      excerpt: "Learn how to interpret your sleep data and make meaningful improvements to your rest quality.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Sarah Wilson",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Sleep Medicine",
      },
      date: "Mar 15, 2025",
      readTime: "5 min read",
      aiCoAuthored: true,
      category: "healthy-living",
    },
    {
      id: 2,
      title: "Heart Rate Variability: The Key to Stress Management",
      excerpt: "Discover how tracking your heart rate variability can help you manage stress and improve recovery.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Michael Chen",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Cardiology",
      },
      date: "Mar 12, 2025",
      readTime: "7 min read",
      aiCoAuthored: true,
      category: "mental-health",
    },
    {
      id: 3,
      title: "Optimizing Your Daily Activity Based on Wearable Data",
      excerpt: "How to use your activity metrics to create a personalized exercise plan that works for you.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Emily Brown",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Sports Medicine",
      },
      date: "Mar 10, 2025",
      readTime: "6 min read",
      aiCoAuthored: true,
      category: "healthy-living",
    },
    {
      id: 4,
      title: "The Connection Between Sleep and Blood Pressure",
      excerpt: "Research shows strong links between sleep quality and blood pressure regulation. Learn more.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. James Rodriguez",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Hypertension",
      },
      date: "Mar 8, 2025",
      readTime: "4 min read",
      aiCoAuthored: true,
      category: "diseases",
    },
    {
      id: 5,
      title: "Nutrition Strategies for Better Mental Health",
      excerpt:
        "How your diet affects your brain chemistry and what foods can help improve your mood and cognitive function.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Leila Ahmadi",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Nutritional Psychiatry",
      },
      date: "Mar 5, 2025",
      readTime: "8 min read",
      aiCoAuthored: false,
      category: "nutrition",
    },
    {
      id: 6,
      title: "Skin Care Essentials: Building an Effective Routine",
      excerpt: "Dermatologist-approved steps for maintaining healthy skin at any age.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Hadi Sadeghi",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Dermatology",
      },
      date: "Mar 3, 2025",
      readTime: "5 min read",
      aiCoAuthored: true,
      category: "skin-hair",
    },
    {
      id: 7,
      title: "Pregnancy and Exercise: Safe Workout Guidelines",
      excerpt:
        "Expert advice on staying active during pregnancy while protecting your health and your baby's development.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Maryam Samadi",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Obstetrics",
      },
      date: "Feb 28, 2025",
      readTime: "6 min read",
      aiCoAuthored: false,
      category: "mother-child",
    },
    {
      id: 8,
      title: "New Medications for Type 2 Diabetes Management",
      excerpt:
        "A review of the latest pharmaceutical options for controlling blood sugar and preventing complications.",
      image: "/placeholder.svg?height=200&width=400",
      author: {
        name: "Dr. Ali Rahmani",
        avatar: "/placeholder.svg?height=40&width=40",
        specialty: "Endocrinology",
      },
      date: "Feb 25, 2025",
      readTime: "7 min read",
      aiCoAuthored: true,
      category: "medications",
    },
  ]

  const filteredArticles =
    activeCategory === "all" ? articles : articles.filter((article) => article.category === activeCategory)

  const itemsPerPage = 3
  const totalPages = Math.ceil(filteredArticles.length / itemsPerPage)

  const handlePrevious = () => {
    setCurrentPage((prev) => (prev === 0 ? totalPages - 1 : prev - 1))
  }

  const handleNext = () => {
    setCurrentPage((prev) => (prev === totalPages - 1 ? 0 : prev + 1))
  }

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category)
    setCurrentPage(0) // Reset to first page when changing categories
  }

  const visibleArticles = filteredArticles.slice(currentPage * itemsPerPage, (currentPage + 1) * itemsPerPage)

  return (
    <Card className="border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold">Health Insights</h2>
            <p className="text-sm text-muted-foreground">Articles based on your health data</p>
          </div>
          <Button variant="ghost" size="sm" className="text-blue-600">
            <ArrowLeft className="mr-1 h-4 w-4" />
            View all articles
          </Button>
        </div>

        {/* Category Navigation */}
        <div className="mb-6">
          <ArticleCategories onCategoryChange={handleCategoryChange} activeCategory={activeCategory} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {visibleArticles.map((article) => (
            <Card key={article.id} className="overflow-hidden border hover:shadow-md transition-shadow">
              <div className="relative h-40 w-full">
                <img
                  src={article.image || "/placeholder.svg"}
                  alt={article.title}
                  className="object-cover w-full h-full"
                />
                {article.aiCoAuthored && (
                  <Badge className="absolute top-2 right-2 bg-blue-600">
                    <Star className="mr-1 h-3 w-3" /> Co-Ai
                  </Badge>
                )}
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold line-clamp-2 mb-2">{article.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{article.excerpt}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Avatar className="h-6 w-6 mr-2">
                      <AvatarImage src={article.author.avatar} alt={article.author.name} />
                      <AvatarFallback>{article.author.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs">{article.author.name}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{article.readTime}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {totalPages > 1 && (
          <div className="flex justify-center mt-6">
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="icon" onClick={handlePrevious}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }).map((_, index) => (
                <Button
                  key={index}
                  variant={currentPage === index ? "default" : "outline"}
                  size="icon"
                  className={`w-8 h-8 ${currentPage === index ? "bg-blue-600" : ""}`}
                  onClick={() => setCurrentPage(index)}
                >
                  {index + 1}
                </Button>
              ))}
              <Button variant="outline" size="icon" onClick={handleNext}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

