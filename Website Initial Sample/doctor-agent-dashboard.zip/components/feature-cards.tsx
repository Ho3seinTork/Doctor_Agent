"use client"

import { ArrowRight, FlaskRoundIcon as Flask, Pill, AlertTriangle, Cpu } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface FeatureCardsProps {
  onCoAiClick: () => void
}

export function FeatureCards({ onCoAiClick }: FeatureCardsProps) {
  const features = [
    {
      title: "CO-AI",
      description: "Collaborate with AI for medical insights",
      detailedDescription:
        "Our advanced AI system analyzes medical data to provide personalized insights, assist with diagnoses, and suggest treatment options based on the latest research and clinical guidelines.",
      icon: <Cpu className="h-16 w-16 text-medical-primary" />,
      color: "bg-blue-50 border-blue-200",
      size: "large-left",
      action: () => onCoAiClick(),
    },
    {
      title: "Laboratory",
      description: "View and track Lab test Results",
      icon: <Flask className="h-7 w-7 text-indigo-500" />,
      color: "bg-indigo-50 border-indigo-200",
      size: "medium-left",
      action: () => console.log("Laboratory clicked"),
    },
    {
      title: "Start of Special visit",
      description: "Begin your specialized consultation",
      icon: <ArrowRight className="h-6 w-6 text-green-500" />,
      color: "bg-green-50 border-green-200",
      highlight: true,
      size: "small-center",
      action: () => console.log("Special visit clicked"),
    },
    {
      title: "Pharmacy",
      description: "Manage prescriptions and medications",
      icon: <Pill className="h-7 w-7 text-purple-500" />,
      color: "bg-purple-50 border-purple-200",
      size: "medium-right",
      action: () => console.log("Pharmacy clicked"),
    },
    {
      title: "Emergency",
      description: "Quick access to emergency services",
      detailedDescription:
        "Connect instantly with emergency medical professionals for urgent health concerns. Our priority response system ensures you receive immediate guidance, triage assessment, and coordination with local emergency services when needed.",
      icon: <AlertTriangle className="h-16 w-16 text-red-500" />,
      color: "bg-red-50 border-red-200",
      size: "large-right",
      action: () => console.log("Emergency clicked"),
    },
  ]

  return (
    <div className="mb-10">
      <div className="flex justify-between items-end w-full h-[300px]">
        {features.map((feature, index) => {
          // Define size classes based on the sketch but enlarged
          const sizeClasses = {
            "large-left": "w-[25%] h-[280px]",
            "medium-left": "w-[15%] h-[200px]",
            "small-center": "w-[12%] h-[140px]",
            "medium-right": "w-[18%] h-[200px]",
            "large-right": "w-[23%] h-[270px]",
          }[feature.size]

          // Determine if this is a large side card
          const isLargeSideCard = feature.size === "large-left" || feature.size === "large-right"

          return (
            <Card
              key={index}
              className={`border cursor-pointer hover:shadow-md transition-all ${feature.color} ${
                feature.highlight ? "ring-2 ring-green-300" : ""
              } ${sizeClasses} rounded-md overflow-hidden mx-[2px]`}
              style={{
                borderRadius: "4px",
                borderWidth: "1px",
                // Add slight irregularity to mimic hand-drawn look
                transform: `rotate(${Math.random() * 1 - 0.5}deg) skew(${Math.random() * 1 - 0.5}deg)`,
              }}
              onClick={feature.action}
            >
              <CardContent className="p-4 flex flex-col items-center text-center justify-center h-full">
                <div className={`${isLargeSideCard ? "mb-4" : "mb-3"}`}>{feature.icon}</div>
                <h3 className={`font-semibold mb-2 ${isLargeSideCard ? "text-2xl" : "text-base"}`}>{feature.title}</h3>
                <p className={`${isLargeSideCard ? "text-base" : "text-sm"} text-gray-600 line-clamp-3`}>
                  {feature.description}
                </p>
                {feature.detailedDescription && (
                  <p className="text-xs text-gray-500 mt-2 line-clamp-4">{feature.detailedDescription}</p>
                )}
                {feature.highlight && <ArrowRight className="h-5 w-5 text-green-500 mt-3" />}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

