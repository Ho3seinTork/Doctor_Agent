"use client"

import { useState } from "react"
import {
  Search,
  Home,
  Stethoscope,
  Cpu,
  FolderOpen,
  AlertTriangle,
  User,
  Bell,
  MapPin,
  BotIcon as Robot,
  Menu,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Logo } from "./logo"
import { useIsMobile } from "@/hooks/use-mobile"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/button"

export function Header() {
  const isMobile = useIsMobile()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navItems = [
    { label: "Home", icon: <Home className="h-4 w-4" /> },
    { label: "Find a Doctor", icon: <Stethoscope className="h-4 w-4" /> },
    { label: "AI Diagnosis", icon: <Cpu className="h-4 w-4" /> },
    { label: "Medical Records", icon: <FolderOpen className="h-4 w-4" /> },
    { label: "Emergency", icon: <AlertTriangle className="h-4 w-4 text-red-500" /> },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        {/* Logo */}
        <div className="mr-4">
          <Logo />
        </div>

        {/* Mobile menu toggle */}
        {isMobile && (
          <Button variant="ghost" size="icon" className="ml-auto" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        )}

        {/* Desktop Navigation */}
        {!isMobile && (
          <>
            {/* Search Bar */}
            <div className="mx-4 flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search doctors, symptoms, treatments..."
                  className="w-full pl-9 bg-muted/50 border-muted"
                />
              </div>
            </div>

            {/* Navigation Menu */}
            <nav className="mx-6 flex items-center space-x-4 lg:space-x-6">
              {navItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className={`flex items-center gap-1.5 ${item.label === "Emergency" ? "text-red-500 hover:text-red-600 hover:bg-red-50" : ""}`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </Button>
              ))}
            </nav>

            {/* Right Side Elements */}
            <div className="ml-auto flex items-center space-x-4">
              {/* Location Selector */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-1.5">
                    <MapPin className="h-4 w-4 text-medical-primary" />
                    <span className="text-sm">New York</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>New York</DropdownMenuItem>
                  <DropdownMenuItem>Los Angeles</DropdownMenuItem>
                  <DropdownMenuItem>Chicago</DropdownMenuItem>
                  <DropdownMenuItem>Houston</DropdownMenuItem>
                  <DropdownMenuItem>Phoenix</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Notifications */}
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center bg-medical-primary text-white text-[10px]">
                  3
                </Badge>
              </Button>

              {/* User Menu */}
              <Button variant="outline" size="sm" className="gap-1.5">
                <User className="h-4 w-4" />
                <span>Sign In</span>
              </Button>

              {/* CTA Button */}
              <Button className="gap-1.5 bg-medical-primary hover:bg-medical-secondary">
                <Robot className="h-4 w-4" />
                <span>AI Diagnosis</span>
              </Button>
            </div>
          </>
        )}
      </div>

      {/* Mobile Menu */}
      {isMobile && mobileMenuOpen && (
        <div className="container py-4 border-t">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search doctors, symptoms, treatments..."
                className="w-full pl-9 bg-muted/50 border-muted"
              />
            </div>
          </div>

          <nav className="grid gap-2">
            {navItems.map((item, index) => (
              <Button
                key={index}
                variant="ghost"
                className={`justify-start ${item.label === "Emergency" ? "text-red-500 hover:text-red-600 hover:bg-red-50" : ""}`}
              >
                {item.icon}
                <span className="ml-2">{item.label}</span>
              </Button>
            ))}
          </nav>

          <div className="mt-4 grid gap-2">
            <Button variant="outline" size="sm" className="justify-start gap-1.5">
              <MapPin className="h-4 w-4 text-medical-primary" />
              <span>New York</span>
            </Button>

            <Button variant="outline" size="sm" className="justify-start gap-1.5">
              <User className="h-4 w-4" />
              <span>Sign In</span>
            </Button>

            <Button className="mt-2 gap-1.5 bg-medical-primary hover:bg-medical-secondary">
              <Robot className="h-4 w-4" />
              <span>AI Diagnosis</span>
            </Button>
          </div>
        </div>
      )}
    </header>
  )
}

