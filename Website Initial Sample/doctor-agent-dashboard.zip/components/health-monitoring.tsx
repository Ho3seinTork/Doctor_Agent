"use client"

import { Heart, Footprints, Activity, Moon } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface BarProps {
  height: number
  color: string
  active?: boolean
}

const Bar = ({ height, color, active = false }: BarProps) => (
  <div className="flex h-full items-end">
    <div
      className={`w-3 rounded-t-sm ${color} ${active ? "opacity-100" : "opacity-70"}`}
      style={{ height: `${height}%` }}
    ></div>
  </div>
)

const SleepBar = ({ width, color }: { width: number; color: string }) => (
  <div className={`h-full ${color}`} style={{ width: `${width}%` }}></div>
)

export function HealthMonitoring() {
  // Generate random heights for heart rate bars
  const heartRateBars = Array.from({ length: 12 }, () => Math.floor(Math.random() * 50) + 30)

  // Generate random heights for steps bars
  const stepsBars = Array.from({ length: 12 }, () => Math.floor(Math.random() * 50) + 30)

  return (
    <Card className="border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold">Wearable Health Data</h2>
            <p className="text-sm text-muted-foreground">Data from your connected devices</p>
          </div>
          <Tabs defaultValue="day" className="w-[240px]">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="day">Day</TabsTrigger>
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="month">Month</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Heart Rate Panel */}
          <Card className="border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Heart className="h-5 w-5 text-red-500 mr-2" />
                  <span className="font-medium">Heart Rate</span>
                </div>
                <span className="text-sm text-green-500">-5%</span>
              </div>

              <div className="flex items-end space-x-1">
                <span className="text-4xl font-bold">72</span>
                <span className="text-lg text-muted-foreground mb-1">BPM</span>
              </div>

              <div className="h-24 mt-4 bg-gray-100 rounded-md p-2">
                <div className="flex justify-between h-full">
                  {heartRateBars.map((height, i) => (
                    <Bar key={i} height={height} color={i === 6 ? "bg-red-600" : "bg-red-400"} active={i === 6} />
                  ))}
                </div>
              </div>

              <p className="text-sm text-muted-foreground mt-2">Resting heart rate: 68 BPM</p>
            </CardContent>
          </Card>

          {/* Steps Panel */}
          <Card className="border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Footprints className="h-5 w-5 text-blue-500 mr-2" />
                  <span className="font-medium">Steps</span>
                </div>
                <span className="text-sm text-green-500">+12%</span>
              </div>

              <div className="flex items-end space-x-1">
                <span className="text-4xl font-bold">8,742</span>
                <span className="text-lg text-muted-foreground mb-1">steps</span>
              </div>

              <div className="h-24 mt-4 bg-gray-100 rounded-md p-2">
                <div className="flex justify-between h-full">
                  {stepsBars.map((height, i) => (
                    <Bar key={i} height={height} color={i === 7 ? "bg-blue-600" : "bg-blue-400"} active={i === 7} />
                  ))}
                </div>
              </div>

              <p className="text-sm text-muted-foreground mt-2">Goal: 10,000 steps (87% complete)</p>
            </CardContent>
          </Card>

          {/* Activity Panel */}
          <Card className="border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Activity className="h-5 w-5 text-purple-500 mr-2" />
                  <span className="font-medium">Activity</span>
                </div>
                <span className="text-sm text-green-500">+8%</span>
              </div>

              <div className="flex items-end space-x-1">
                <span className="text-4xl font-bold">42</span>
                <span className="text-lg text-muted-foreground mb-1">minutes</span>
              </div>

              <div className="grid grid-cols-3 gap-2 mt-4">
                <div className="bg-purple-100 p-3 rounded-md">
                  <p className="text-purple-700">Walking</p>
                  <p className="font-bold">25 min</p>
                </div>
                <div className="bg-purple-100 p-3 rounded-md">
                  <p className="text-purple-700">Running</p>
                  <p className="font-bold">12 min</p>
                </div>
                <div className="bg-purple-100 p-3 rounded-md">
                  <p className="text-purple-700">Cycling</p>
                  <p className="font-bold">5 min</p>
                </div>
              </div>

              <p className="text-sm text-muted-foreground mt-4">Daily goal: 60 minutes (70% complete)</p>
            </CardContent>
          </Card>

          {/* Sleep Panel */}
          <Card className="border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <Moon className="h-5 w-5 text-indigo-500 mr-2" />
                  <span className="font-medium">Sleep</span>
                </div>
                <span className="text-sm text-red-500">-3%</span>
              </div>

              <div className="flex items-end space-x-1">
                <span className="text-4xl font-bold">6.5</span>
                <span className="text-lg text-muted-foreground mb-1">hours</span>
              </div>

              <div className="h-12 mt-4 bg-gray-100 rounded-md flex overflow-hidden">
                <SleepBar width={15} color="bg-indigo-300" />
                <SleepBar width={30} color="bg-indigo-400" />
                <SleepBar width={40} color="bg-indigo-600" />
                <SleepBar width={15} color="bg-indigo-300" />
              </div>

              <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                <span>10:45 PM</span>
                <div className="flex items-center space-x-2">
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-indigo-300 mr-1"></div>
                    <span>Light</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-indigo-400 mr-1"></div>
                    <span>Deep</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-indigo-600 mr-1"></div>
                    <span>REM</span>
                  </div>
                </div>
                <span>5:15 AM</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}

