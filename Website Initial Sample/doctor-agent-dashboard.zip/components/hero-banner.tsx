"use client"
import { Button } from "@/components/ui/button"

export function HeroBanner() {
  return (
    <div className="w-full mb-6 overflow-hidden rounded-lg shadow-md">
      <div className="relative bg-gradient-to-r from-medical-primary/10 to-medical-secondary/10 p-8 md:p-12">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-800 mb-6">Banner Site Doctor Agent</h1>
          <Button className="bg-medical-primary hover:bg-medical-secondary text-white px-6 py-2 rounded-md text-lg">
            Start Visit
          </Button>
        </div>
      </div>
    </div>
  )
}

