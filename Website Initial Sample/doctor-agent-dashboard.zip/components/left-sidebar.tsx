"use client"

import { useState } from "react"
import { FileText, MessageSquare, Search, ChevronRight, Star } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/button"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"

export function LeftSidebar() {
  const [recentChats] = useState([
    { id: 1, name: "Dr. Sarah Wilson", avatar: "/placeholder.svg?height=40&width=40", online: true },
    { id: 2, name: "Dr. Emily Brown", avatar: "/placeholder.svg?height=40&width=40", online: false },
    { id: 3, name: "Dr. Michael Chen", avatar: "/placeholder.svg?height=40&width=40", online: true },
  ])

  const [recentSearches] = useState(["Blood pressure medication", "Headache symptoms", "Vitamin D deficiency"])

  const [medicalRecords] = useState([
    { id: 1, title: "Annual Checkup", date: "2025-02-15", doctor: "Dr. Wilson" },
    { id: 2, title: "Blood Test Results", date: "2025-01-20", doctor: "Dr. Chen" },
    { id: 3, title: "Vaccination Record", date: "2024-12-05", doctor: "Dr. Brown" },
    { id: 4, title: "Allergy Test", date: "2024-11-10", doctor: "Dr. Wilson" },
  ])

  return (
    <Sidebar collapsible="offcanvas">
      <SidebarHeader className="p-4">
        <div className="flex items-center space-x-3">
          <Avatar className="h-10 w-10 border border-border">
            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
            <AvatarFallback>SR</AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="font-medium">Sorosh Raziani</span>
            <span className="text-xs text-muted-foreground">@sorosh</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="overflow-y-auto" style={{ maxHeight: "calc(100vh - var(--header-height) - 80px)" }}>
        {/* Premium Plan */}
        <SidebarGroup>
          <div className="mx-4 mb-2 rounded-lg border border-border bg-accent/30 p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Star className="h-5 w-5 text-medical-primary" />
                <span className="font-medium">Premium Plan</span>
              </div>
              <Badge variant="outline" className="bg-medical-primary text-white hover:bg-medical-secondary">
                Active
              </Badge>
            </div>
            <button className="mt-2 w-full rounded-md border border-medical-primary bg-transparent px-3 py-1 text-sm text-medical-primary hover:bg-medical-accent">
              Manage Subscription
            </button>
          </div>
        </SidebarGroup>

        {/* Medical Records */}
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center">
            <FileText className="mr-2 h-4 w-4" />
            My Medical Records
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {medicalRecords.map((record) => (
                <SidebarMenuItem key={record.id}>
                  <SidebarMenuButton className="flex justify-between">
                    <div className="flex flex-col items-start">
                      <span>{record.title}</span>
                      <span className="text-xs text-muted-foreground">{record.date}</span>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Recent Chats */}
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center">
            <MessageSquare className="mr-2 h-4 w-4" />
            My Chats
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {recentChats.map((chat) => (
                <SidebarMenuItem key={chat.id}>
                  <SidebarMenuButton className="flex items-center space-x-2">
                    <div className="relative">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={chat.avatar} alt={chat.name} />
                        <AvatarFallback>{chat.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      {chat.online && (
                        <span className="absolute bottom-0 right-0 h-2 w-2 rounded-full bg-green-500 ring-1 ring-white"></span>
                      )}
                    </div>
                    <span>{chat.name}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Recent Searches */}
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center">
            <Search className="mr-2 h-4 w-4" />
            Recent Searches
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {recentSearches.map((search, index) => (
                <SidebarMenuItem key={index}>
                  <SidebarMenuButton className="flex items-center">
                    <Search className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span className="truncate">{search}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarRail />
    </Sidebar>
  )
}

