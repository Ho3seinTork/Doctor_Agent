import { Stethoscope } from "lucide-react"

export function Logo() {
  return (
    <div className="flex items-center gap-1.5">
      <div className="relative">
        <div className="bg-gradient-to-r from-medical-primary to-medical-secondary rounded-full p-1.5">
          <Stethoscope className="h-6 w-6 text-white" />
        </div>
      </div>
      <div className="font-bold text-lg">
        <span className="text-gray-800">Doctor</span>
        <span className="text-medical-primary">Agent</span>
      </div>
    </div>
  )
}

