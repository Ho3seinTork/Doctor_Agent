"use client"

import type React from "react"

import { Building2, Hospital, Microscope, Camera, Stethoscope } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface Facility {
  id: string
  name: string
  count: number
  icon: React.ReactNode
  highlighted?: boolean
}

export function MedicalFacilities() {
  const facilities: Facility[] = [
    {
      id: "imaging",
      name: "Imaging Centers",
      count: 33,
      icon: <Camera className="h-8 w-8 text-blue-500" />,
    },
    {
      id: "clinics",
      name: "Clinics",
      count: 540,
      icon: <Building2 className="h-8 w-8 text-blue-500" />,
    },
    {
      id: "hospitals",
      name: "Hospitals",
      count: 42,
      icon: <Hospital className="h-8 w-8 text-blue-500" />,
    },
    {
      id: "labs",
      name: "Laboratories",
      count: 77,
      icon: <Microscope className="h-8 w-8 text-blue-500" />,
    },
    {
      id: "medical-centers",
      name: "Medical Centers",
      count: 37,
      icon: <Stethoscope className="h-8 w-8 text-white" />,
      highlighted: true,
    },
  ]

  return (
    <div className="w-full mb-8">
      <h2 className="text-xl font-semibold mb-6">Medical Facilities</h2>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
        {facilities.map((facility) => (
          <Card
            key={facility.id}
            className={`overflow-hidden border ${facility.highlighted ? "bg-blue-500 text-white" : "bg-white"}`}
          >
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className={`rounded-full ${facility.highlighted ? "bg-white" : "bg-blue-50"} p-4 mb-4`}>
                {facility.icon}
              </div>
              <h3 className="font-semibold text-base mb-1">{facility.name}</h3>
              <p className={`text-sm ${facility.highlighted ? "text-blue-100" : "text-gray-600"}`}>
                {facility.count} {facility.name.toLowerCase()}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

