"use client"

import { useState } from "react"
import { Home, MessageSquare, User, Bell } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { LeftSidebar } from "./left-sidebar"
import { RightPanel } from "./right-panel"

export function MobileNav() {
  const [activeTab, setActiveTab] = useState("home")

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full border-t bg-background md:hidden">
      <div className="flex items-center justify-around p-2">
        <Button
          variant="ghost"
          size="icon"
          className={activeTab === "home" ? "text-medical-primary" : "text-muted-foreground"}
          onClick={() => setActiveTab("home")}
        >
          <Home className="h-5 w-5" />
        </Button>

        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className={activeTab === "messages" ? "text-medical-primary" : "text-muted-foreground"}
              onClick={() => setActiveTab("messages")}
            >
              <MessageSquare className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="p-0">
            <RightPanel />
          </SheetContent>
        </Sheet>

        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className={activeTab === "profile" ? "text-medical-primary" : "text-muted-foreground"}
              onClick={() => setActiveTab("profile")}
            >
              <User className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0">
            <LeftSidebar />
          </SheetContent>
        </Sheet>

        <Button
          variant="ghost"
          size="icon"
          className={activeTab === "notifications" ? "text-medical-primary" : "text-muted-foreground"}
          onClick={() => setActiveTab("notifications")}
        >
          <Bell className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}

