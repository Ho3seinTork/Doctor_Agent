"use client"

import { MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"

interface RightPanelTriggerProps {
  onToggle: () => void
  isOpen: boolean
}

export function RightPanelTrigger({ onToggle, isOpen }: RightPanelTriggerProps) {
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={onToggle}
      className={isOpen ? "text-medical-primary" : "text-muted-foreground"}
      aria-label={isOpen ? "Close chat panel" : "Open chat panel"}
    >
      <MessageSquare className="h-5 w-5" />
    </Button>
  )
}

