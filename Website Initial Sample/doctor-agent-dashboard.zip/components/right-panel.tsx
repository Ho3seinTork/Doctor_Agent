"use client"

import { useState } from "react"
import { Send, ImageIcon, Paperclip, Mic, Users, Loader2 } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

interface Message {
  id: number
  sender: string
  avatar: string
  content: string
  timestamp: string
  isUser: boolean
  isAI: boolean
}

export function RightPanel() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      sender: "Dr. Sarah Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      content: "Hello! How can I help you today?",
      timestamp: "10:30 AM",
      isUser: false,
      isAI: false,
    },
    {
      id: 2,
      sender: "You",
      avatar: "/placeholder.svg?height=40&width=40",
      content: "I've been experiencing headaches for the past few days.",
      timestamp: "10:32 AM",
      isUser: true,
      isAI: false,
    },
    {
      id: 3,
      sender: "AI Assistant",
      avatar: "/placeholder.svg?height=40&width=40",
      content:
        "I'm sorry to hear that. Could you describe the pain? Is it constant or intermittent? Any other symptoms?",
      timestamp: "10:32 AM",
      isUser: false,
      isAI: true,
    },
  ])

  const [connecting, setConnecting] = useState(true)
  const [messageInput, setMessageInput] = useState("")

  // Simulate connecting to doctor after 3 seconds
  setTimeout(() => {
    setConnecting(false)
  }, 3000)

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      const newMessage: Message = {
        id: messages.length + 1,
        sender: "You",
        avatar: "/placeholder.svg?height=40&width=40",
        content: messageInput,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isUser: true,
        isAI: false,
      }
      setMessages([...messages, newMessage])
      setMessageInput("")
    }
  }

  return (
    <div className="flex h-full flex-col border-l">
      <div className="flex items-center justify-between border-b p-4">
        <div className="flex items-center space-x-2">
          <Users className="h-5 w-5 text-medical-primary" />
          <h2 className="font-semibold">Group Chat</h2>
        </div>
        <Tabs defaultValue="all">
          <TabsList className="grid w-[160px] grid-cols-2">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="doctors">Doctors</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={cn("flex items-start space-x-2", message.isUser && "justify-end")}>
              {!message.isUser && (
                <Avatar className="h-8 w-8">
                  <AvatarImage src={message.avatar} alt={message.sender} />
                  <AvatarFallback>{message.isAI ? "AI" : message.sender.charAt(0)}</AvatarFallback>
                </Avatar>
              )}
              <div
                className={cn(
                  "max-w-[80%] rounded-lg px-3 py-2",
                  message.isUser
                    ? "bg-medical-primary text-white"
                    : message.isAI
                      ? "bg-medical-accent text-foreground"
                      : "bg-muted",
                )}
              >
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-medium">{message.sender}</span>
                  <span className="text-xs opacity-70">{message.timestamp}</span>
                </div>
                <p className="mt-1">{message.content}</p>
              </div>
              {message.isUser && (
                <Avatar className="h-8 w-8">
                  <AvatarImage src={message.avatar} alt="You" />
                  <AvatarFallback>You</AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}

          {connecting && (
            <div className="flex items-center justify-center rounded-lg bg-muted p-3">
              <Loader2 className="mr-2 h-4 w-4 animate-spin text-medical-primary" />
              <span>Connecting to Doctor...</span>
            </div>
          )}
        </div>
      </div>

      {/* Message Input */}
      <div className="border-t p-4">
        <div className="relative">
          <Textarea
            placeholder="Type a message..."
            className="min-h-[80px] resize-none pr-12"
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                handleSendMessage()
              }
            }}
          />
          <div className="absolute bottom-2 right-2 flex items-center space-x-1">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <ImageIcon className="h-4 w-4 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <Paperclip className="h-4 w-4 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
              <Mic className="h-4 w-4 text-muted-foreground" />
            </Button>
            <Button
              onClick={handleSendMessage}
              className="h-8 w-8 rounded-full bg-medical-primary hover:bg-medical-secondary"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="mt-2 text-xs text-muted-foreground">
          AI-enhanced composition is enabled. Press Tab to accept suggestions.
        </div>
      </div>
    </div>
  )
}

