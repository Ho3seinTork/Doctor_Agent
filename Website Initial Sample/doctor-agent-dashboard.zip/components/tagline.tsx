export function Tagline() {
  return (
    <div className="w-full mb-8 text-center">
      <h2 className="text-xl md:text-2xl font-semibold text-gray-800 mb-2">
        Doctor Agent - <span className="text-medical-primary">Faster, More Accurate</span>
      </h2>
      <p className="text-lg text-gray-700">Healthcare with AI. Anytime. Anywhere.</p>
    </div>
  )
}

