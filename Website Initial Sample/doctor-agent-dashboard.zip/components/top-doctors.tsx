"use client"

import { useState } from "react"
import { MapPin, ChevronLeft, ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Doctor {
  id: number
  name: string
  specialty: string
  location: string
  image: string
}

export function TopDoctors() {
  const [currentPage, setCurrentPage] = useState(0)

  const doctors: Doctor[] = [
    {
      id: 1,
      name: "Dr. Sarah Wilson",
      specialty: "Obstetrics & Gynecology",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 2,
      name: "Dr. Hadi Sadeghi",
      specialty: "Orthopedic Surgery",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 3,
      name: "Dr. Maryam Samadi",
      specialty: "Dentistry",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 4,
      name: "Dr. Dara Hoakimian",
      specialty: "Psychology",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 5,
      name: "Dr. Michael Chen",
      specialty: "Cardiology",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 6,
      name: "Dr. Emily Brown",
      specialty: "Dermatology",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 7,
      name: "Dr. Ali Rahmani",
      specialty: "Neurology",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
    {
      id: 8,
      name: "Dr. Leila Ahmadi",
      specialty: "Pediatrics",
      location: "Tehran",
      image: "/placeholder.svg?height=80&width=80",
    },
  ]

  const totalPages = Math.ceil(doctors.length / 4)
  const displayedDoctors = doctors.slice(currentPage * 4, (currentPage + 1) * 4)

  const goToNextPage = () => {
    setCurrentPage((prev) => (prev === totalPages - 1 ? 0 : prev + 1))
  }

  const goToPrevPage = () => {
    setCurrentPage((prev) => (prev === 0 ? totalPages - 1 : prev - 1))
  }

  return (
    <div className="w-full mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Top Doctors of the Week</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={goToPrevPage}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={goToNextPage}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {displayedDoctors.map((doctor) => (
          <Card key={doctor.id} className="overflow-hidden">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <Avatar className="h-24 w-24 mb-4 border-2 border-blue-100">
                <AvatarImage src={doctor.image} alt={doctor.name} />
                <AvatarFallback>{doctor.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <h3 className="font-semibold text-lg mb-1">{doctor.name}</h3>
              <p className="text-sm text-gray-600 mb-2">{doctor.specialty}</p>
              <div className="flex items-center text-gray-500 text-sm mb-4">
                <MapPin className="h-3 w-3 mr-1" />
                <span>{doctor.location}</span>
              </div>
              <Button
                variant="outline"
                className="w-full border-medical-primary text-medical-primary hover:bg-medical-accent"
              >
                Make Appointment
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-center mt-6">
        <div className="flex gap-2">
          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              className={`h-2 w-2 rounded-full ${currentPage === index ? "bg-medical-primary" : "bg-gray-200"}`}
              onClick={() => setCurrentPage(index)}
              aria-label={`Go to page ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

