"use client"

import { useState } from "react"
import { Search, Home, Stethoscope, FolderOpen, AlertTriangle, Bell, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Logo } from "./logo"
import { useIsMobile } from "@/hooks/use-mobile"
import { Badge } from "@/components/ui/button"

interface UnifiedHeaderProps {
  rightPanelOpen: boolean
  onRightPanelToggle: () => void
}

export function UnifiedHeader({ rightPanelOpen, onRightPanelToggle }: UnifiedHeaderProps) {
  const isMobile = useIsMobile()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navItems = [
    { label: "Home", icon: <Home className="h-5 w-5" /> },
    { label: "Doctors", icon: <Stethoscope className="h-5 w-5" /> },
    { label: "Medical Records", icon: <FolderOpen className="h-5 w-5" /> },
    { label: "Emergency", icon: <AlertTriangle className="h-5 w-5 text-red-500" /> },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      {/* Main header */}
      <div className="container flex h-16 items-center justify-between">
        {/* Left side - Logo */}
        <div className="flex items-center gap-4">
          <Logo />
        </div>

        {/* Center - Search */}
        <div className="hidden md:block flex-1 max-w-md mx-4">
          <div className="relative">
            <Input
              type="search"
              placeholder="Deep truth search"
              className="w-full pl-12 pr-4 h-11 bg-gray-100 border-gray-200 rounded-lg text-sm"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          </div>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center gap-3">
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative h-11 w-11 text-gray-600">
            <Bell className="h-6 w-6" />
            <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center bg-red-500 text-white text-[10px]">
              3
            </Badge>
          </Button>

          {/* Login/Sign Up */}
          <Button variant="outline" size="sm" className="h-11 text-sm gap-1.5 border border-gray-200 rounded-lg px-4">
            <LogIn className="h-4 w-4 text-gray-600 mr-1" />
            <span>Login/Sign up</span>
          </Button>
        </div>
      </div>

      {/* Secondary navigation */}
      <div className="border-t border-gray-100 bg-white">
        <div className="container flex items-center h-12 overflow-x-auto scrollbar-hide">
          {/* Navigation items */}
          {navItems.map((item, index) => (
            <Button
              key={index}
              variant="ghost"
              className={`h-full text-sm gap-2 rounded-none border-b-2 border-transparent hover:border-medical-primary px-4 ${
                item.label === "Emergency" ? "text-red-500" : "text-gray-700"
              }`}
            >
              {item.icon}
              <span className="whitespace-nowrap">{item.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobile && mobileMenuOpen && (
        <div className="container py-4 border-t">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                type="search"
                placeholder="Deep truth search"
                className="w-full pl-12 pr-4 h-11 bg-gray-100 border-gray-200 rounded-lg text-sm"
              />
            </div>
          </div>

          <nav className="grid gap-2">
            {navItems.map((item, index) => (
              <Button
                key={index}
                variant="ghost"
                className={`justify-start ${item.label === "Emergency" ? "text-red-500" : ""}`}
              >
                {item.icon}
                <span className="ml-2">{item.label}</span>
              </Button>
            ))}
          </nav>
        </div>
      )}
    </header>
  )
}

